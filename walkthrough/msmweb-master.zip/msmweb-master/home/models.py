from django.db import models

# Create your models here.

class Packages(models.Model):
    destination = models.CharField(max_length=500)
    p_name = models.CharField(max_length=500)
    desc = models.CharField(max_length=5000)
    duration = models.CharField(max_length=5000)
    pdf = models.FileField()

    def __str__(self):
        return "{}".format( self.destination)


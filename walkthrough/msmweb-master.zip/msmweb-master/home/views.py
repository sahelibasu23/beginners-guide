from django.shortcuts import render, redirect
from django.core.mail import  send_mail
from.models import *

# Create your views here.

def index(request):
    return render(request, 'index.html')

def About(request):
    return render(request, 'about.html')

def Booking(request):
    return render(request, 'booking.html')

def Contact(request):
    if request.method == 'GET':
        return render(request, 'contact.html')
    elif request.method == 'POST':
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        msg=request.POST['msg']
        subject = "Mail From Website"
        comment =" Name: " + name + "\n\n" + " Email: "+ email + "\n\n" + "Phone:" + phone  + "\n\n" + name + ", sent this following message to you:\n\n" + msg;
        send_mail(subject, comment, email, ['msmtourstravels19@gmail.com'])

        return redirect('/contact/')

def Services(request):
    return render(request, 'services.html')

def packages(request):
    if request.method == 'GET':
        p = Packages.objects.all()
        context = {"data":p}
        return render(request, 'packages.html',context)


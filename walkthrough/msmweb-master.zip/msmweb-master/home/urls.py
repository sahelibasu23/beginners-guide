from django.urls import path
from .views import *


urlpatterns = [
    path('', index, name='index'),
    path('about/', About, name='About'),
    path('contact/', Contact, name='Contact'),
    path('services/', Services, name='Services'),
    path('booking/', Booking, name='Booking'),
    path('packages/', packages, name='Packages')
]
